
function predict() {
  const inputDate = document.getElementById("lastPeriod").value;
  if (!inputDate) {
    alert("Please enter a valid date.");
    return;
  }

  const lastDate = new Date(inputDate);
  const nextPeriod = new Date(lastDate);
  nextPeriod.setDate(nextPeriod.getDate() + 28);

  const ovulationDate = new Date(lastDate);
  ovulationDate.setDate(ovulationDate.getDate() + 14);

  const fertileStart = new Date(lastDate);
  fertileStart.setDate(fertileStart.getDate() + 10);

  const fertileEnd = new Date(lastDate);
  fertileEnd.setDate(fertileEnd.getDate() + 15);

  const options = { year: 'numeric', month: 'long', day: 'numeric' };

  document.getElementById("results").innerHTML = `
    <p><strong>Next Period:</strong> ${nextPeriod.toLocaleDateString(undefined, options)}</p>
    <p><strong>Ovulation:</strong> ${ovulationDate.toLocaleDateString(undefined, options)}</p>
    <p><strong>Fertile Window:</strong> ${fertileStart.toLocaleDateString(undefined, options)} to ${fertileEnd.toLocaleDateString(undefined, options)}</p>
  `;
}
